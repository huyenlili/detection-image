# Copyright (c) OpenMMLab. All rights reserved.
from .base import BaseTestDataset

__all__ = ['BaseTestDataset']
