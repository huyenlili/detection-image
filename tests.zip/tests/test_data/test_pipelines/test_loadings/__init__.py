# Copyright (c) OpenMMLab. All rights reserved.
from .base import BaseTestLoading

__all__ = ['BaseTestLoading']
