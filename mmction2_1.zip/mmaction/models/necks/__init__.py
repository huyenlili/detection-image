# Copyright (c) OpenMMLab. All rights reserved.
from .tpn import TPN

__all__ = ['TPN']
