# Copyright (c) OpenMMLab. All rights reserved.
from .lr_updater import TINLrUpdaterHook

__all__ = ['TINLrUpdaterHook']
